execute as @a at @s run playsound minecraft:ui.toast.challenge_complete master @s ~ ~ ~ 100 1
